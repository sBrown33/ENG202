%% Torque Calculations for 17hs4401

% Parameters
K = 40/1.7;
I = 1:0.1:7;
t = I/800;
RPM = 60./(200*t);
ss = 1./t;

% Speed range
T = K*I;

% Plot torque vs. speed
figure;
plot(RPM, T, '-b');
xlabel('RPM');
ylabel('Torque (N*cm)');

% Plot torque vs. steps/second
figure;
plot(ss, T, '-b');
xlabel('steps/second');
ylabel('Torque (N*cm)');





