/*
 * stepper-driver.cpp
 *
 * Created: 23/06/2022 5:35:14 PM
 * Author : apm3
 */ 

#define F_CPU 16000000UL		// Define the on-board external clock as 16 Mhz

#define SPEED_LOW 130			// steps/second (nominal)
#define SPEED_HIGH 570			// steps/second (nominal)
#define DEBOUNCE_DELAY 3200		//debounce delay

#include <avr/io.h>
#include <avr/interrupt.h>
//#include <stdlib.h>
#include <stdio.h>
#include "stepper.h"
#include "uart_out.h"
#include "AS5600.h"

// enum typedefs
enum state_t {
	STATE_IDLE,
	STATE_DRIVE,
	STATE_WAIT};
	
enum stepper_mode_t {
	MODE_IDLE,
	MODE_DRIVE};
	
enum dir_t {
	DIR_FORWARD,
	DIR_REVERSE};
	
// Function declarations
void init_adc(void);
void init_gpio(void);
void init_loop_timer(void);
void init_stepper_timer(void);
int16_t stepper_update(stepper_mode_t stepper_mode, uint16_t target_stepper_pos, uint16_t stepper_pos);
void state_machine(void);

// Global variables
uint8_t STEPPER_UPDATE = false;
uint8_t STATE_UPDATE = false;

volatile uint16_t adc_values[2];

volatile uint8_t PB_state = false;
volatile uint8_t Dir_state = false;		//Direction var (false = backwards)
volatile uint8_t LS1_state = false;
volatile uint8_t LS2_state = false;

volatile uint16_t PB_debounce_timer = 0;
volatile uint16_t LS1_debounce_timer = 0;
volatile uint16_t LS2_debounce_timer = 0;

volatile uint16_t sprint_timer = 0;

int16_t target_stepper_pos = 0;
stepper_mode_t stepper_mode = MODE_IDLE;
int16_t stepper_pos = 0;
int16_t encoder_pos = 0;

uint16_t stepper_period_offset = 0;

step_mode_t drive_mode = MODE_FULL;

int main(void)
{
	// Initializations
	init_stepper(drive_mode);
	init_uart(F_CPU,9600);
	init_as5600();
	init_adc();
	init_gpio();
	init_loop_timer();
	init_stepper_timer();
	
	// Global interrupt enable
	sei();
	
	println("Starting");
	
    while (1) 
    {	
		debounce_update();		//reduces active debounce timers
		
		sprint();	//increases speed after 60 seconds
						
		if (STATE_UPDATE) // if STATE_UPDATE flag is set update the state machine logic
		{
			STATE_UPDATE = false;
			
			PINB |= (1<<PINB5); // toggle activity LED
			
			state_machine();
		}
    }
}

//Counts the debounce timers to zero
void debounce_update()
{
	if (LS1_debounce_timer > 0)
	{
		LS1_debounce_timer--;
	}

	if (LS2_debounce_timer > 0)
	{
		LS2_debounce_timer--;
	}

	if (PB_debounce_timer > 0)
	{
		PB_debounce_timer--;
	}
}

//Speed set high 60 seconds after start
void sprint()
{
	if(PB_state)
	{
		sprint_timer++;
		if(sprint_timer>6000)
		{
			stepper_period_offset = 0xFFFF - (250000/(SPEED_HIGH));
			target_stepper_pos = 0;
		}
	}
	else
	{
		sprint_timer = 0;
	}
}

// Intializes the ADC to be auto triggering based off timer 1 (same timer as DAC output)
void init_adc()
{
	// Set pins as input and disable the pullup
	DDRC &= ~(1 << DDRC0) & ~(1 << DDRC1);
	PORTC &= ~(1 << PORTC0) & ~(1 << PORTC1);
	
	// Set the reference voltage as AVCC
	ADMUX = ADMUX & ~(1<<REFS1) | (1 << REFS0);
	// Set data as right justified (can set to left justified and read only ADCL if 8-bit precision is enough)
	ADMUX &= ~(1 << ADLAR);
	// Select prescaler for ADC clock
	// This controls the sample & conversion time
	ADCSRA = ADCSRA | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
	// Enable auto-triggering based on Timer1 overflow
	ADCSRB = ADCSRB | (1 << ADTS2) | (1 << ADTS1) & ~(1 << ADTS0); // set auto-trigger source as Timer 1 overflow
	ADCSRA |= (1 << ADATE);	// Enable auto-triggering
	// Disable digital input buffer on ADC pins
	DIDR0 |= (1 << ADC0D) | (1 << ADC1D);
	// Enable the interrupt on conversion
	ADCSRA |= (1 << ADIE);
	// Enable the ADC
	ADCSRA |= (1 << ADEN);
}

// sets up PCINT2 and the misc GPIO not associated with another driver
void init_gpio()
{
	// LS1, LS2, PB as inputs
	DDRD &= ~(1 << DDRD2) & ~(1 << DDRD4) & ~(1 << DDRD7);
	PORTD &= ~(1 << PORTD2) & ~(1 << PORTD4) & ~(1 << PORTD7);
	
	// LED as output
	//DDRC |= (1 << DDRC3);
	//PORTC &= ~(1 << PORTC3); // initilize LOW
	
	DDRC &= ~(1 << DDRC3);	//Set Dir as an input
	PORTC &= ~(1 << PORTC3);	//Set direction to forward
	
	// Onboard Xplained Mini PB5 LED as STATE toggle indicator
	DDRB |= (1 << DDRB5);
	PORTB &= ~(1 << PORTB5);
	
	// enable pcint masks
	PCMSK2 |= (1 << PCINT18) | (1 << PCINT20) | (1 << PCINT23);
	// enable PCINT2
	PCICR |= (1 << PCIE2);
}

// sets up the period timer to control update rate of stepper motor updates
void init_stepper_timer()
{
	// Setup mode timer mode
	TCCR3A = 0b00001100;	// normal mode (non-pwm or input capture)
	TCCR3B &= ~(0b11<<WGM32);//
	
	// Eg. Frequency of ~100Hz.
	// F_CPU = 16MHz.
	// Ftmr = F_CPU / (PRE * (1 + TOP))
	// Where TOP is (2^16)-1, and PRE = 1, 8, 64, 256, or 1024
	// Set PRE = 8 we need TCNT initial value = 2^16 - 1 - 20000 = 45,535 = 0xB1DF
	
	// With PRE = 64, have speed of ~3.8steps/s - 250,000 steps/second.
	
	// start with 200 steps/s
	// need period of 1250 counts
	// need offset of 2^16-1250 = 64,286
	
	stepper_period_offset = 0xFB1E;
	
	TCNT4L = 0x1E;
	TCNT4H = 0xFB;
	
	// Setup prescaler
	TCCR3B = TCCR3B & ~(1<<CS32) | (1<<CS31) | (1<<CS30);	// 0b011 = F_CPU/64
	// Enable timer overflow interrupt
	TIMSK3 |= (1 << TOIE3);
}

// sets up the main period timer to control update rate of state machine
void init_loop_timer()
{
	// Setup mode timer mode
	TCCR4A = 0b00001100;	// normal mode (non-pwm or input capture)
	TCCR4B &= ~(0b11<<WGM42);//
	
	// Eg. Frequency of 10Hz.
	// F_CPU = 16MHz.
	// Ftmr = F_CPU / (PRE * (1 + TOP))
	// Where TOP is (2^16)-1, and PRE = 1, 8, 64, 256, or 1024
	// Set PRE = 64 we need TCNT initial value = 2^16 - 1 - 25000 = 40,535 = 0x9E57
	
	TCNT4L = 0x57;
	TCNT4H = 0x9E;
	
	// Setup prescaler
	TCCR4B = TCCR4B & ~(1<<CS42) | (1<<CS41) | (1<<CS40);	// 0b011 = F_CPU/64
	// Enable timer overflow interrupt
	TIMSK4 |= (1 << TOIE4);
}

void state_machine(void)
{
	// This function will be executed periodically
	// and actions must be performed asynchronously from other tasks (eg STEPPER_UPDATE)
	// so this function should be non-halting (no while loops and fast execution time).
	
	static state_t state;	// By default the state machine stays in the current state.
	static uint16_t speed = SPEED_LOW;
	static dir_t direction = DIR_FORWARD;
	
	//uint16_t angle = read_angle();
	uint16_t angle = read_raw_angle();
	
	char buff[200];
	sprintf(buff,"State: %u, Angle: %u, I1: %u, I2: %u, pos: %u, target: %u",state, angle, adc_values[0], adc_values[1], stepper_pos, target_stepper_pos);
	println(buff);	
	
	switch(state)
	{
		case STATE_IDLE:
			// 1. Collect and process any inputs
			
			// 2. Perform any actions
			//PORTC &= ~(1<<PORTC3);
					
			// 3. Calculate the next state
			state = STATE_WAIT;
			
			break;
		case STATE_DRIVE:
			// 1. Collect and process any inputs
			
			// get encoder and stepper position
			// calculate encoder position from angle
			// handle any mismatch by adjusting the target stepper position
			// calculate absolute position on beam
			
			// 2. Perform any actions
			
			// update the stepper motor mode and target position
			stepper_mode = MODE_DRIVE;
			
			//PORTC |= (1<<PORTC3); // user indicator LED on
			
			// 3. Calculate the next state
			if (stepper_pos == target_stepper_pos)
			{
				stepper_mode = MODE_IDLE;
				
				state = STATE_WAIT;
				
				if (direction == DIR_FORWARD)
				{
					direction = DIR_REVERSE;
					speed = SPEED_HIGH;
					// to change speed, set the start offset to set the count period
					stepper_period_offset = 0xFFFF - (250000/(speed)); 
					target_stepper_pos = 0;
				}
				else
				{
					direction = DIR_FORWARD;
					speed = SPEED_LOW;
					// to change speed, set the start offset to set the count period
					stepper_period_offset = 0xFFFF - (250000/(speed));
					target_stepper_pos = 400;
				}
			}
			
			break;
		case STATE_WAIT:
			// 1. Collect and process any inputs
			static uint16_t wait_count = 0;	
			static uint16_t wait_time = 20;		
			
			// 2. Perform any actions
			
			//PINC |= (1<<PINC3); // Toggle user indicator LED
			
			wait_count++; // increment loop count
			
			// 3. Calculate the next state
			
			if (wait_count > wait_time)
			{
				state = STATE_DRIVE;
				wait_count = 0;
			}
			
			break;
	}
}

int16_t stepper_update(stepper_mode_t stepper_mode, uint16_t target_stepper_pos, uint16_t stepper_pos)
{
	switch (stepper_mode)
	{
		case MODE_IDLE:
			idle_motor();
			break;
		case MODE_DRIVE:
			uint16_t step;
			if (target_stepper_pos > stepper_pos) step = target_stepper_pos - stepper_pos;
			else step = stepper_pos - target_stepper_pos;
			
			uint8_t dir;
			
			if (Dir_state)
			{
				dir = 1;
			}
			else
			{
				dir = 0;
			}
			
			if (step)
			{
				step_motor(dir);
				if (dir) stepper_pos++;
				else stepper_pos--;
			}
	}
	return stepper_pos;
}

// Interrupts

// Timer to control timing of stepper update
ISR(TIMER3_OVF_vect)
{
	// set TCNT3L and TCNT3H to some value to set precise period
	TCNT3 = stepper_period_offset;
	
	stepper_pos = stepper_update(stepper_mode, target_stepper_pos, stepper_pos);
}

// Timer to control timing of periodic updates
// Alternativley, this could run at some multiple of stepper updates (timer 3 overflows)
ISR(TIMER4_OVF_vect)
{
	// set TCNT4L and TCNT4H to some value to set precise period
	TCNT4 = 0x9E57;
	STATE_UPDATE = true;
}

// ADC Conversion complete
ISR(ADC_vect)
{	// ADC conversion is triggered by Timer 1 by default, which is used to generate VREF by the stepper driver at ~500 Hz.
	// Alternatively, the ADC could be manually triggered in the main loop.
	// We can only read one ADC value at a time so our sampling rate will be halved.
	
	// For now the values are simply read and stored for interpretation/use by the state machine logic
	// This could be modified to add each value to a buffer and compute the mean or a filtered value
	adc_values[ADMUX&(1<<MUX0)] = ADCL | (ADCH << 8);
	
	// Change the channel to read the other pin on next trigger
	ADMUX ^= (1 << MUX0);
}

// General pcint for user input controls and limit switches
ISR(PCINT2_vect)
{
	// Read the pin values to determine which pin changed
	// For some pins we might only care about a rising edge
	
	
	if (~(PIND&(1<<PIND2)) && LS1_debounce_timer==0) // LS1 pressed
	{
		LS1_state = true;
		LS1_debounce_timer = DEBOUNCE_DELAY;
	}
	
	if (~(PIND&(1<<PIND4)) && LS2_debounce_timer==0) // LS2 pressed
	{
		LS2_state = true;
		LS2_debounce_timer = DEBOUNCE_DELAY;
	}
	
		
	if (~(PIND&(1<<PIND7)) && PB_debounce_timer==0) // PB pressed
	{
		PB_state = true;
		PB_debounce_timer = DEBOUNCE_DELAY;
	}
	else if (PB_debounce_timer==0)
	{
		PB_state = false;
		PB_debounce_timer = DEBOUNCE_DELAY;
	}
}
