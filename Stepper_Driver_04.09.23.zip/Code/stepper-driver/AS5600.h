
#ifndef __AS5600_LIB__
	#define __AS5600_LIB__

	#include <stdint.h>
	#include "i2c.h"

	static const uint8_t _ams5600_Address = 0x36;
	
	static const uint8_t _addr_raw_angle = 0x0c;	// raw angle
													// 0x0d - lower byte
	static const uint8_t _addr_angle     = 0x0e;	// mapped angle
													// 0x0f - lower byte

	void init_as5600(void);
	uint16_t read_angle(void);
	uint16_t read_raw_angle(void);

#endif // __AS5600_LIB__