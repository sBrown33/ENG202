#include "AS5600.h"

void init_as5600(void)
{
	init_i2c(I2C_100K,false);
}

uint16_t read_angle(void)
{
	uint16_t angle;
	
	// write to as5600 the target address to read
	i2c_tx(_ams5600_Address, (uint8_t*) &_addr_angle , 2);
		
	// Read 2 bytes from as5600, stored in array at ptr.
	i2c_rx(_ams5600_Address, (uint8_t*) &angle, 2);
	
	return angle;
}

uint16_t read_raw_angle(void)
{
	uint16_t raw_angle;
	
	// write to as5600 the target address to read
	i2c_tx(_ams5600_Address, (uint8_t*) &_addr_raw_angle, 2);
	
	// Read 2 bytes from as5600, stored in array at ptr.
	i2c_rx(_ams5600_Address, (uint8_t*) &raw_angle, 2);
	
	return raw_angle;
}