#include "i2c.h"

// -------------------------------------------------------------------------
void init_i2c(i2cSpeed_t i2cClock, bool enablePullup)
{
	DDRC &= ~(1 << TW_SDA_PIN);		// set as input
	DDRC &= ~(1 << TW_SCL_PIN);
  
	if(enablePullup)
    { // set as 1 to turn on pullups
		PORTC |= (1 << TW_SDA_PIN);
		PORTC |= (1 << TW_SCL_PIN);
    }
	else
    { // set as 0 to turn off pullups
		PORTC &= ~(1 << TW_SDA_PIN);
		PORTC &= ~(1 << TW_SCL_PIN);
    }

	// clk freq calc = cpu / (16 + 2*TWBR0*1)
	switch(i2cClock)
    {
		case I2C_100K: TWBR0 = 72; break;
		case I2C_250K: TWBR0 = 24; break;
		case I2C_400K: TWBR0 = 12; break;
    }
  }

// -------------------------------------------------------------------------
uint16_t i2c_start(void)
{
	// send start
	TWCR0 = (1 << TWINT) | (1 << TWEN) | (1 << TWSTA);
	
	// wait for init flag
	while(!(TWCR0 & (1 << TWINT)));
	
	// check status
	if(TWSR0 != TW_START && TWSR0 != TW_REP_START) return TWSR0;
	
	return 0;
}


// -------------------------------------------------------------------------
void i2c_stop(void)
{
	// send stop
	TWCR0 = (1 << TWINT) | (1 << TWEN) | (1 << TWSTO);
}


// -------------------------------------------------------------------------
uint16_t i2c_set_slave(uint8_t slaveAddr)
{
	// tx slave address with r/w flag
	TWDR0 = slaveAddr;
	TWCR0 = (1 << TWINT) | (1 << TWEN);
	
	// wait for init flag
	while(!(TWCR0 & (1 << TWINT)));

	if (TWSR0 != TW_MT_SLA_ACK && TWSR0 != TW_MR_SLA_ACK) return TWSR0;

	return 0;
}


// -------------------------------------------------------------------------
uint16_t i2c_write(uint8_t data)
{
	// tx 1 byte
	TWDR0 = data;
	TWCR0 = (1 << TWINT) | (1 << TWEN);
	
	// wait for init flag
	while(!(TWCR0 & (1 << TWINT)));

	if (TWSR0 != TW_MT_DATA_ACK) return TWSR0;
	
	return 0;
}


// -------------------------------------------------------------------------
uint8_t i2c_read(bool ack)
{
	if(ack)
	{
		TWCR0 = (1 << TWINT) | (1 << TWEN) | (1 << TWEA);
		// wait for init flag
		while(!(TWCR0 & (1 << TWINT)));
	
  		if (TWSR0 != TW_MR_DATA_ACK) return TWSR0; // return error
    }
	else
    {
		TWCR0 = (1 << TWINT) | (1 << TWEN);
		// wait for init flag
		while(!(TWCR0 & (1 << TWINT)));
		if (TWSR0 != TW_MR_DATA_NACK) return TWSR0; // return error
    }
	
	return TWDR0;
}


// -------------------------------------------------------------------------
uint16_t i2c_tx(uint8_t slave_addr, uint8_t *data, uint8_t len)
{
	uint16_t error;
	
	// send start error
	if((error = i2c_start()) != 0) return error;
	
	// send slave addr and write flag
	if((error = i2c_set_slave(TW_SLA_W(slave_addr)) != 0)) return error;
	
	// send byte(s)
	for(uint8_t i = 0; i<len; ++i)
		if((error = i2c_write(data[i])) != 0) return error;
	
	i2c_stop();
	return 0;
}


// -------------------------------------------------------------------------
uint16_t i2c_rx(uint8_t slave_addr, uint8_t *data, uint8_t len)
{
	uint16_t error;
  
	// send start error
	if((error = i2c_start()) != 0) return error;
	
	// write slave addr with read flag
	if ((error = i2c_set_slave(TW_SLA_R(slave_addr))) != 0) return error;

	// read byte(s) and send ack
	for (int i = 0; i < len-1; ++i)
		data[i] = i2c_read(TW_READ_ACK);

	data[len-1] = i2c_read(TW_READ_NACK);
	
	// send stop
	i2c_stop();
	
	return 0;
}

