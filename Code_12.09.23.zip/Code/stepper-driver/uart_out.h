/*
 * uart_out.h
 *
 * Created: 9/10/2020 9:18:36 AM
 *  Author: shogwood
 */ 


#ifndef __UART_OUT_H__
#define __UART_OUT_H__

	#ifndef F_CPU
	#define F_CPU 16000000UL
	#endif

	#include <avr/io.h>

	// -----------------------------------------
	void init_uart(uint32_t f_cpu, uint16_t setBaud);

	// -----------------------------------------
	void write(char ch);
	void write(uint8_t num);
	void write16(uint64_t num);
	void write32(uint64_t num);
	void write64(uint64_t num);

	// -----------------------------------------
	void print(const char *str);
	void println(const char *str);
	void crlf(void);

	void print64(uint64_t num);


#endif // __UART_OUT_H__