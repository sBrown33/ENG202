/*
 * uart_out.cpp
 *
 * Created: 9/10/2020 9:19:32 AM
 *  Author: shogwood
 */ 

#include "uart_out.h"

#include <stdlib.h>

// ================================================================================

uint16_t baud = 0;
uint16_t baudRate = 0;

//#define BAUD 9600								 // define baud
//#define BAUDRATE (((F_CPU / (BAUD * 16UL))) - 1) // set baud rate

// ================================================================================
void init_uart(uint32_t f_cpu, uint16_t setBaud)
{
	baud = setBaud;
	baudRate = (((f_cpu / (baud * 16UL))) - 1);
	
	UBRR0H = (baudRate >> 8);
	UBRR0L = (baudRate);
	UCSR0B =  (1 << TXEN0); //(1 << RXEN0) |
	UCSR0C = (1 << UCSZ00) | (1 << UCSZ01) | (0 << USBS0);
}

// -----------------------------------------
void writeUART(uint8_t b)
{
	while(!(UCSR0A & (1 << UDRE0))) ;
	UDR0 = b;
}

// ================================================================================

void write(char ch)
{
	writeUART(ch);
}

// -----------------------------------------
void write(uint8_t num)
{
	writeUART(num);
}


// -----------------------------------------
void write16(uint16_t num)
{
	writeUART(num >> 8);
	writeUART(num);
}

// -----------------------------------------
void write32(uint32_t num)
{
	writeUART(num >> 24);
	writeUART(num >> 16);
	writeUART(num >> 8);
	writeUART(num);
}

// -----------------------------------------
void write64(uint64_t num)
{
	writeUART(num >> 56);
	writeUART(num >> 48);
	writeUART(num >> 40);
	writeUART(num >> 32);        
	writeUART(num >> 24);
	writeUART(num >> 16);
	writeUART(num >> 8);
	writeUART(num);
}


// ================================================================================

char s[100] = {0};  
  
// -----------------------------------------
void print64(uint64_t num)
{
	ultoa(num, s, 10);
	print(s);
}

// -----------------------------------------
void print(const char *str)
{
	while(*str)
	{
		while(!(UCSR0A & (1 << UDRE0))) ;
		UDR0 = *str++;
	}
}

// -----------------------------------------
void println(const char *str)
{
	print(str);
	crlf();
} 

// -----------------------------------------
void crlf(void)
{
	writeUART('\r');
	writeUART('\n');
}


