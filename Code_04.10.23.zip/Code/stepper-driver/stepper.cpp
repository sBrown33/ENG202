
#include <avr/io.h>
#include <avr/interrupt.h>

#include "stepper.h"

const uint8_t STATE_MASK = N_STATES-1; // generate mask for number of states (eg. for 16 states will be 0b11111)
const uint16_t P1A_MASK = ((VAL_WIDTH*2)-1)<<(3*VAL_WIDTH);
const uint16_t P1B_MASK = ((VAL_WIDTH*2)-1)<<(2*VAL_WIDTH);
const uint16_t P2A_MASK = ((VAL_WIDTH*2)-1)<<(VAL_WIDTH);
const uint16_t P2B_MASK = ((VAL_WIDTH*2)-1);

static uint8_t P1A;
static uint8_t P1B;
static uint8_t P2A;
static uint8_t P2B;

static uint8_t VREF1;
static uint8_t VREF2;

static uint8_t step_inc = 2;			// full-wave stepping is default
static float max_i_fac = 1.0;			// maximum current. 1 corresponds to 5V Vref

// Function declarations
void init_dac(void);

/*
 * For full-wave stepping we have 2 phases with two current values (positive +, negative -)
 * and we are controlling this with four control lines each with two values (on 1 or off 0)
 * and we have four states or quadrants
 * (P1P2) = ++,+-,--,-+
 * (P1AP1BP2AP2B) = 1010, 0110, 0101, 1001
 *
 * For half stepping we have 2 phases with three current values (positive +, off 0, negative -)
 * and we are controlling this with four control lines each with two values (on 1 or off 0)
 * and we have eight states or quadrants
 * (P1P2) = ++,+0,+-,0-,--,-0,-+,0+
 * (P1AP1BP2AP2B) = 1010, 1000, 1001, 0001, 0101, 0100, 0110, 0010
 * Note that the half-stepping includes the full-wave stepping states (state 0,2,4,6)
 *
 * To generalise this to microstepping (N*4 quadrants)
 * We have N*4 states, which will always include the original full-wave states at state 0,N/2,N,3N/2
 * But we now have additional values (currents are not just positive, off or negative).
 * In fact we have N values (we can ignore the 50% current in both phases and just provide the full current)
 */
static const unsigned int step_lookup[N_STATES] = 
{	
	0x3000, 0x2001, 0x3003, 0x1002, 
	0x0003, 0x0102,	0x0303, 0x0201,
	0x0300, 0x0210, 0x0330, 0x0120, 
	0x0030, 0x1020, 0x3030, 0x2010
};


// also need lookup for trig values of N+1 length
// this is here in case you want to implement micro-stepping
static const unsigned char i_lookup[N_VALS] = 
{
	0, 97, 157, 255
};


/*
 * Function		init_stepper
 * Desc			initializes the four PWM outputs
 *				used to drive each phases HIGH and LO input.
 * Input		none
 * Output		none
 */
void init_stepper(step_mode_t mode, bool enable_current_limit, float max_current_percentage)
{
	if (mode)
	{
		step_inc = MAX_STEP_DIV/mode;
	}
	else
	{
		step_inc = 0;
	}

	max_i_fac = max_current_percentage;
	
	// Set pins as output
	DDRD |= (1 << DDRD5);	// P1A
	DDRD |= (1 << DDRD6);	// P1B
	DDRB |= (1 << DDRB3);	// P2A
	DDRD |= (1 << DDRD3);	// P2B
	// Set outputs low
	PORTD &= ~(1 << PORTD5);	// P1A
	PORTD &= ~(1 << PORTD6);	// P1B
	PORTB &= ~(1 << PORTB3);	// P2A
	PORTD &= ~(1 << PORTD3);	// P2B
	
	// Set pin change interrupt pins as inputs and disable pullups
	DDRB &= ~(1 << DDRB0);		// P1
	DDRC &= ~(1 << DDRC2);		// P2
	PORTB &= ~(1 << PORTB0);	// P1
	PORTC &= ~(1 << PORTC2);	// P2
	
	// Configure Timers
	// Timer 0 (P1)
	TCCR0A = TCCR0A | (1 << WGM00) | (1 << WGM01);
	TCCR0B = TCCR0B & ~(1 << WGM02);					// WGM0[2:0] = 0b011 = Fast PWM Mode
	// F_PWM = F_CPU / (PRE*(MAX+1)) PRE = prescaler divider (1,8,64,256,1024), MAX = 255
	// With PRE = 1, F_DAC ~ 62.5kHz
	// PRE 1 -> CS0[2:0] = 0b001
	TCCR0B = ((TCCR0B & ~(1 << CS02)) & ~(1 << CS01)) | (1 << CS00); // Set Prescaler to F_CPU/1
	
	// Timer 2 (P2)
	TCCR2A = TCCR2A | (1 << WGM20) | (1 << WGM21);
	TCCR2B = TCCR2B & ~(1 << WGM22);					// WGM2[2:0] = 0b011 = Fast PWM Mode
	// F_PWM = F_CPU / (PRE*(MAX+1)) PRE = prescaler divider (1,8,64,256,1024), MAX = 255
	// With PRE = 1, F_DAC ~ 62.5kHz
	// PRE 1 -> CS2[2:0] = 0b001
	TCCR2B = TCCR2B & ~(1 << CS22) & ~(1 << CS21) | (1 << CS20); // Set Prescaler to F_CPU/1
	
	// Initialize OCR registers
	idle_motor();
	
	// Enable Timer Overflow Interrupts
	TIMSK0 |= (1 << TOIE0);	// Enable overflow interrupt for TMR0
	TIMSK2 |= (1 << TOIE2);	// Enable overflow interrupt for TMR2
	
	
	// Enable pin change interrupts on comparator input pins
	PCMSK0 |= (1 << PCINT0);	// P1
	PCMSK1 |= (1 << PCINT10);	// P2
	PCICR |= (1 << PCIE1) | (1 << PCIE0);
	
	// If we are using a software controlled current limit
	// (microstepping or instead of external pot)
	// Enable the DAC outptut and related interrupts
	if (enable_current_limit)
	{
		init_dac();	
	}
}


/*
 * Function		init_dac
 * Desc			initializes the two PWM outputs
 *				used as analogue Vrefs for each phase.
 * Input		none
 * Output		none
 */
void init_dac(void)
{
	// Set pins as output
	DDRB |= (1 << DDRB1) | (1 << DDRB2);
	// Set outputs low
	PORTB &= ~(1 << PORTB1) & ~(1 << PORTB2);
	// Configure Timer
	TCCR1A = TCCR1A | (1 << COM1A1) & ~(1 << COM1A0);	// Output A non-inverting
	TCCR1A = TCCR1A | (1 << COM1B1) & ~(1 << COM1B0); // Output B non-inverting
	TCCR1A = TCCR1A & ~(1 << WGM11) | (1 << WGM10);
	TCCR1B = TCCR1B & ~(1 << WGM13) | (1 << WGM12);	// Fast PWM 8-bit 0b0101
	// F_DAC = F_CPU / (PRE*(1+TOP)) PRE = prescaler divider (1,8,64,256,1024), TOP = 255
	// With PRE = 8, F_DAC ~ 8 kHz
	// PRE 8 -> CS[12:10] = 0b010
	TCCR1B = TCCR1B & ~(1 << CS12) | (1 << CS11) & ~(1 << CS10); // Set Prescaler to F_CPU/8
	// Initialize OCR registers
	OCR1AL = 0xFF;	// only need low register as we are using 8-bit fast PWM mode
	OCR1BL = 0xFF;	// Initialize to maximum VREF output
	// Enable Interrupts
	TIMSK1 |= (1 << TOIE1);	// Enable overflow interrupt
}

/*
 * Function		step_motor
 * Desc			steps the motor by one step (depends on microstep setting)
 * Input		dir: boolean indicating direction to increment step, true = positive, false = negative
 * Output		none
 */
void step_motor(uint8_t dir)
{
	static uint8_t current_step = 0; // current_step will stay in memory between function calls. It is only initialized once.
	
	// get the new value from the lookup table
	if (dir) current_step += step_inc;
	else current_step -= step_inc;
	uint16_t step_val = step_lookup[current_step & STATE_MASK];
	
	// Phase 1
	P1A = (step_val & P1A_MASK) >> (3*VAL_WIDTH);
	P1B = (step_val & P1B_MASK) >> (2*VAL_WIDTH);
	
	OCR0A = i_lookup[P1A];						// Set OC reg for P1A
	OCR0B = i_lookup[P1B];						// Set OC reg for P1B. One of OCR0A and OCR0B should be zero.
	VREF1 = i_lookup[P1A|P1B]*max_i_fac;		// Set Vref for P1
	if (P1A) // P1A active
	{
		//PORTD |= (1 << PORTD5);	// P1A
		//PORTD &= ~(1 << PORTD6);	// P1B
		
		TCCR0A &= ~(0b11<<COM0B0);				// Disable P1B output
		PORTD &= ~(1 << PORTD6);				// and drive low
		TCCR0A |= ((0b11&OC_MODE)<<COM0A0);		// Enable P1A output
	}
	else if (P1B) // P1B active
	{
		//PORTD &= ~(1 << PORTD5);	// P1A
		//PORTD |= (1 << PORTD6);	// P1B
		
		TCCR0A &= ~(0b11<<COM0A0);				// Disable P1A output
		PORTD &= ~(1 << PORTD5);				// And drive low
		TCCR0A |= ((0b11&OC_MODE)<<COM0B0);		// Enable P1B output
	}
	else // P1 inactive
	{
		//PORTD &= ~(1 << PORTD5);	// P1A
		//PORTD &= ~(1 << PORTD6);	// P1B
		
		TCCR0A &= ~(0b11<<COM0A0) & ~(0b11<<COM0B0);	// Disable P1A and P1B outputs
		PORTD &= ~(1 << PORTD5);						// Drive P1A low
		PORTD &= ~(1 << PORTD6);						// Drive P1B low
	}
	
	// Phase 2
	P2A = (step_val & P2A_MASK) >> (VAL_WIDTH);
	P2B = (step_val & P2B_MASK);
	
	OCR2A = i_lookup[P2A];						// Set OC reg for P2A
	OCR2B = i_lookup[P2B];						// Set OC reg for P2B. One of OCR2A and OCR2B should be zero.
	VREF2 = i_lookup[P2A|P2B]*max_i_fac;		// Set Vref for P2
	if (P2A) // P1A active
	{
		//PORTB |= (1 << PORTB3);	// P2A
		//PORTD &= ~(1 << PORTD3);	// P2B
		
		TCCR2A &= ~(0b11<<COM2B0);				// Disable P2B output
		PORTD &= ~(1 << PORTD3);				// Drive P2B low
		TCCR2A |= ((0b11&OC_MODE)<<COM2A0);		// Enable P2A output
	}
	else if (P2B) // P1B active
	{
		//PORTB &= ~(1 << PORTB3);	// P2A
		//PORTD |= (1 << PORTD3);	// P2B
		
		TCCR2A &= ~(0b11<<COM2A0);				// Disable P2A output
		PORTB &= ~(1 << PORTB3);				// Drive P2A low
		TCCR2A |= ((0b11&OC_MODE)<<COM2B0);		// Enable P2B output
	}
	else // P2 inactive
	{
		//PORTB &= ~(1 << PORTB3);	// P2A
		//PORTD &= ~(1 << PORTD3);	// P2B
		
		TCCR2A &= ~(0b11<<COM2A0) & ~(0b11<<COM2B0);	// Disable P2A and P2B outputs
		PORTB &= ~(1 << PORTB3);						// Drive P2A low
		PORTD &= ~(1 << PORTD3);						// Drive P2B low
	}
}

/*
 * Function		idle_motor
 * Desc			Disables outputs PWM outputs to all phases and drives output
 *				low to put motor in a low-torque idle state
 * Input		none
 * Output		none
 */
void idle_motor(void)
{
	TCCR0A &= ~(0b11<<COM0A0) & ~(0b11<<COM0B0);	// Disable P1A and P1B outputs
	TCCR2A &= ~(0b11<<COM2A0) & ~(0b11<<COM2B0);	// Disable P2A and P2B outputs
	PORTD &= ~(1<<PORTD5);							// Drive P1A output pins low
	PORTD &= ~(1<<PORTD6);							// Drive P1B output pins low
	PORTB &= ~(1<<PORTB3);							// Drive P2A output pin low
	PORTD &= ~(1<<PORTD3);							// Drive P2B output pin low
}


// Interrupts

// Phase 1 Comparator pin-change interrupt
// Used for constant current control.
// When current sense comparator goes high, the PWM output is driven low which should allow current to fall
// This will then cause a falling edge that will trigger the PWM output to be enabled and current to increase.
ISR(PCINT0_vect)
{
	// Although we have interrupted we don't know if this is a rising or falling edge
	// Read the pin value
	if (PINB & (1 << PINB0)) // If pin value is HIGH -> rising edge trigger
	{
		// Disable PWM output and drive outputs low
		TCCR0A &= ~(0b11<<COM0A0) & ~(0b11<<COM0B0);
		PORTD &= ~(1<<PORTD5);
		PORTD &= ~(1<<PORTD6);
	}
	else // If pin value is LOW -> falling edge trigger
	{
		// Enable PWM output for the appropriate output (A or B or neither)
		if (P1A)
		{
			TCCR0A |= ((0b11 & OC_MODE) << COM0A0);
		}
		else if (P1B)
		{
			TCCR0A |= ((0b11 & OC_MODE) << COM0B0);
		}
	}
}

// Phase 2 Comparator pin-change interrupt
// Used for constant current control.
// When current sense comparator goes high, the PWM output is driven low which should allow current to fall
// This will then cause a falling edge that will trigger the PWM output to be enabled and current to increase.
ISR(PCINT1_vect)
{
	// Although we have interrupted we don't know if this is a rising or falling edge
	// Read the pin value
	if (PINC & (1 << PINC2)) // If pin value is HIGH -> rising edge trigger
	{
		// Disable PWM output and drive outputs low
		TCCR2A &= ~(0b11<<COM2A0) & ~(0b11<<COM2B0);
		PORTB &= ~(1<<PORTB3);
		PORTD &= ~(1<<PORTD3);
	}
	else // If pin value is LOW -> falling edge trigger
	{
		// Enable PWM output for the appropriate output (A or B or neither)
		if (P2A)
		{
			TCCR2A |= ((0b11 & OC_MODE) << COM2A0);
		}
		else if (P2B)
		{
			TCCR2A |= ((0b11 & OC_MODE) << COM2B0);
		}
	}
}

// Timer 0 overflow interrupt
ISR(TIMER0_OVF_vect)
{
	// Reset the OCR registers
	OCR0A = i_lookup[P1A];
	OCR0B = i_lookup[P1B];
}

// Timer 2 overflow interrupt
ISR(TIMER2_OVF_vect)
{
	// Reset the OCR registers
	OCR2A = i_lookup[P2A];
	OCR2B = i_lookup[P2B];
}

// Vref Timer overflow interrupt
ISR(TIMER1_OVF_vect)
{
	// Reset the OCR registers
	OCR1AL = VREF1;
	OCR1BL = VREF2;
}