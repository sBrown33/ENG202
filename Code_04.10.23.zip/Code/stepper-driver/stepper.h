#ifndef __STEPPER_LIB_H__
	#define __STEPPER_LIB_H__
	
	#include <stdint.h>
	#include <stdbool.h>
	
	#define OC_MODE 2 // 0 - port disconnected, 1 - depends on WGM setting, 2 - non-inverting, 3 - inverting
	#define MAX_STEP_DIV 4U		// change this if using higher level of microstepping
	#define VAL_WIDTH 4U		// change this if using higher level of microstepping
								// You will also need to redefine step_lookup and i_lookup
								
	#define N_VALS MAX_STEP_DIV
	#define N_STATES MAX_STEP_DIV*4
	
	enum step_mode_t {	MODE_OFF=0, MODE_FULL=1, MODE_HALF=2, MODE_QUARTER=4}; // 1 - full wave stepping, 2 - half stepping, 3 - quarter stepping
	
	void init_stepper(step_mode_t mode, bool enable_current_limit = false, float max_current_percentage = 1.0);
	
	void step_motor(uint8_t dir);
	void idle_motor(void);

#endif // __STEPPER_LIB_H__