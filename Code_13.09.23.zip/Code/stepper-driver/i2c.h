#ifndef __I2C_LIB__
	#define __I2C_LIB__

	#include <avr/io.h>
	#include <util/twi.h>
	#include <stdint.h>
	#include <stdbool.h>


	#define TW_SCL_PIN			  PORTC5
	#define TW_SDA_PIN			  PORTC4

	#define TW_SLA_W(ADDR)		((ADDR << 1) | TW_WRITE)
	#define TW_SLA_R(ADDR)		((ADDR << 1) | TW_READ)
	#define TW_READ_ACK			  1
	#define TW_READ_NACK		  0


	enum i2cSpeed_t {	I2C_100K,	I2C_250K,	I2C_400K };

	void     init_i2c(i2cSpeed_t i2cClock, bool enablePullup = false);

	uint16_t i2c_tx(uint8_t slaveAddr, uint8_t* data, uint8_t len);
	uint16_t i2c_rx(uint8_t slaveAddr, uint8_t* data, uint8_t len);


#endif // __I2C_LIB__
