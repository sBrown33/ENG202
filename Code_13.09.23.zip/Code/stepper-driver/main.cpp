/*
 * stepper-driver.cpp
 *
 * Created: 23/06/2022 5:35:14 PM
 * Author : apm3
 */

#define F_CPU 16000000UL // Define the on-board external clock as 16 MHz

#define SPEED_LOW 130   // Steps per second (nominal)
#define SPEED_HIGH 570  // Steps per second (nominal)
#define ACCELERATION 10              // Acceleration (needs to be set from testing)
#define ACCELERATION_DISTANCE 200    // Acceleration distance (needs to be set from testing)

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include "stepper.h"
#include "uart_out.h"
#include "AS5600.h"

// Enum typedefs
enum state_t {
    STATE_IDLE,
    STATE_DRIVE,
    STATE_WAIT
};

enum stepper_mode_t {
    MODE_IDLE,
    MODE_DRIVE
};

enum dir_t {
    DIR_FORWARD,
    DIR_REVERSE
};

// Function declarations
void debounce_update(void);
void sprint(void);
void init_adc(void);
void init_gpio(void);
void init_loop_timer(void);
void init_stepper_timer(void);
int16_t stepper_update(stepper_mode_t stepper_mode, uint16_t target_stepper_pos, uint16_t stepper_pos);
void state_machine(void);

// Global variables
uint8_t STEPPER_UPDATE = false;
uint8_t STATE_UPDATE = false;

volatile uint16_t adc_values[2];

//State global variables
volatile uint8_t PB_state = false;
volatile uint8_t Dir_state = false; // Direction var (false = backwards)
volatile uint8_t LS1_state = false;
volatile uint8_t LS2_state = false;
volatile uint8_t sprint_state = false;
volatile uint8_t debounced_state_PB = false;
volatile uint8_t debounced_state_LS1 = false;
volatile uint8_t debounced_state_LS2 = false;

//PB timing global variables
volatile uint32_t PB_press_time_sprint = 0;
volatile uint32_t PB_press_time_debounce = 0;
volatile uint32_t LS1_press_time_debounce = 0;
volatile uint32_t LS2_press_time_debounce = 0;
volatile uint32_t current_time = 0;

//wheel slip global variables
volatile uint8_t wheel_slip = 0;
volatile uint16_t slip_threshold = 100;  // Adjust this value as needed
volatile uint16_t wheel_slip_counter = 0;

int16_t target_stepper_pos = 0;
stepper_mode_t stepper_mode = MODE_IDLE;
int16_t stepper_pos = 0;
int16_t encoder_pos = 0;

uint16_t stepper_period_offset = 0;

step_mode_t drive_mode = MODE_FULL;

int main(void)
{
    // Initializations
    init_stepper(drive_mode);
    init_uart(F_CPU, 9600);
    init_as5600();
    init_adc();
    init_gpio();
    init_loop_timer();
    init_stepper_timer();

    // Global interrupt enable
    sei();

    println("Starting");

    while (1)
    {
        debounce_update(); // Reduce active debounce timers
        sprint(); // Increase speed after 60 seconds

        if (STATE_UPDATE) // If STATE_UPDATE flag is set, update the state machine logic
        {
            STATE_UPDATE = false;
            PINB |= (1 << PINB5); // Toggle activity LED
            state_machine();
        }
    }
}

// Counts the debounce timers to zero
void debounce_update()
{
    if (debounced_state_PB)		//Push button
    {
        PB_press_time_debounce = current_time;
    }
    else if (current_time > PB_press_time_debounce)
    {
        debounced_state_PB = true;
    }
	
	if (debounced_state_LS1)	//Limit switch 1
	{
		LS1_press_time_debounce = current_time;
	}
	else if (current_time > LS1_press_time_debounce)
	{
		debounced_state_LS1 = true;
	}
	
	if (debounced_state_LS2)	//Limit switch 2
	{
		LS2_press_time_debounce = current_time;
	}
	else if (current_time > LS2_press_time_debounce)
	{
		debounced_state_LS2 = true;
	}
}

// Speed set high 60 seconds after start
void sprint()
{
    if (PB_state)
    {
        if (PB_press_time_sprint - current_time >= 60)    // Transition to high speed after 60 seconds
        {
            sprint_state = true;
        }
    }
    else
    {
        PB_press_time_sprint = current_time;
    }
}

// Initializes the ADC to be auto-triggering based on timer 1 (same timer as DAC output)
void init_adc()
{
    // Set pins as input and disable the pullup
    DDRC &= ~(1 << DDRC0) & ~(1 << DDRC1);
    PORTC &= ~(1 << PORTC0) & ~(1 << PORTC1);

    // Set the reference voltage as AVCC
    ADMUX = ADMUX & ~(1 << REFS1) | (1 << REFS0);
    // Set data as right-justified (can set to left-justified and read only ADCL if 8-bit precision is enough)
    ADMUX &= ~(1 << ADLAR);
    // Select prescaler for ADC clock
    // This controls the sample & conversion time
    ADCSRA = ADCSRA | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
    // Enable auto-triggering based on Timer1 overflow
    ADCSRB = ADCSRB | (1 << ADTS2) | (1 << ADTS1) & ~(1 << ADTS0); // Set auto-trigger source as Timer 1 overflow
    ADCSRA |= (1 << ADATE); // Enable auto-triggering
    // Disable digital input buffer on ADC pins
    DIDR0 |= (1 << ADC0D) | (1 << ADC1D);
    // Enable the interrupt on conversion
    ADCSRA |= (1 << ADIE);
    // Enable the ADC
    ADCSRA |= (1 << ADEN);
}

// Sets up PCINT2 and the misc GPIO not associated with another driver
void init_gpio()
{
    // LS1, LS2, PB as inputs
    DDRD &= ~(1 << DDRD2) & ~(1 << DDRD4) & ~(1 << DDRD7);
    PORTD &= ~(1 << PORTD2) & ~(1 << PORTD4) & ~(1 << PORTD7);

    // LED as output
    DDRC |= (1 << DDRC3);
    PORTC &= ~(1 << PORTC3); // Initialize LOW

    // Onboard Xplained Mini PB5 LED as STATE toggle indicator
    DDRB |= (1 << DDRB5);
    PORTB &= ~(1 << PORTB5);

    // Enable pcint masks
    PCMSK2 |= (1 << PCINT18) | (1 << PCINT20) | (1 << PCINT23);
    // Enable PCINT2
    PCICR |= (1 << PCIE2);
}

// Sets up the period timer to control the update rate of stepper motor updates
void init_stepper_timer()
{
    // Setup timer mode
    TCCR3A = 0b00001100; // Normal mode (non-pwm or input capture)
    TCCR3B &= ~(0b11 << WGM32);

    // E.g., Frequency of ~100Hz.
    // F_CPU = 16MHz.
    // Ftmr = F_CPU / (PRE * (1 + TOP))
    // Where TOP is (2^16)-1, and PRE = 1, 8, 64, 256, or 1024
    // Set PRE = 8; we need TCNT initial value = 2^16 - 1 - 20000 = 45,535 = 0xB1DF

    // With PRE = 64, have speed of ~3.8 steps/s - 250,000 steps/second.

    // Start with 200 steps/s
    // Need a period of 1250 counts
    // Need an offset of 2^16-1250 = 64,286

    stepper_period_offset = 0xFB1E;

    TCNT4L = 0x1E;
    TCNT4H = 0xFB;

    // Setup prescaler
    TCCR3B = TCCR3B & ~(1 << CS32) | (1 << CS31) | (1 << CS30); // 0b011 = F_CPU/64
    // Enable timer overflow interrupt
    TIMSK3 |= (1 << TOIE3);
}

// Sets up the main period timer to control the update rate of the state machine
void init_loop_timer()
{
    // Setup timer mode
    TCCR4A = 0b00001100; // Normal mode (non-pwm or input capture)
    TCCR4B &= ~(0b11 << WGM42);

    // E.g., Frequency of 10Hz.
    // F_CPU = 16MHz.
    // Ftmr = F_CPU / (PRE * (1 + TOP))
    // Where TOP is (2^16)-1, and PRE = 1, 8, 64, 256, or 1024
    // Set PRE = 64; we need TCNT initial value = 2^16 - 1 - 25000 = 40,535 = 0x9E57

    TCNT4L = 0x57;
    TCNT4H = 0x9E;

    // Setup prescaler
    TCCR4B = TCCR4B & ~(1 << CS42) | (1 << CS41) | (1 << CS40); // 0b011 = F_CPU/64
    // Enable timer overflow interrupt
    TIMSK4 |= (1 << TOIE4);
}

void state_machine(void)
{
    // This function will be executed periodically
    // and actions must be performed asynchronously from other tasks (e.g., STEPPER_UPDATE)
    // so this function should be non-halting (no while loops and fast execution time).

    static state_t state = STATE_IDLE; // By default, the state machine starts in the idle state.
    static uint16_t speed = SPEED_LOW;
    static dir_t direction = DIR_FORWARD;
    static uint16_t wait_count = 0;
    static uint16_t wait_time = 20;

    uint16_t angle = read_raw_angle();

    char buff[200];
    sprintf(buff, "State: %u, Angle: %u, I1: %u, I2: %u, pos: %u, target: %u", state, angle, adc_values[0], adc_values[1], stepper_pos, target_stepper_pos);
    println(buff);

    switch (state)
    {
        case STATE_IDLE:
        // 1. Collect and process any inputs

        // 2. Perform any actions

        // Check the state of the Push Button (PB)
        if (PB_state && !(LS1_state || LS2_state))
        {
            // If PB is pressed, transition to STATE_WAIT
            state = STATE_WAIT;
        }

        // 3. Calculate the next state
        break;

        case STATE_DRIVE:
        // 1. Collect and process any inputs

        // Get encoder and stepper position
        // Calculate encoder position from angle
        // Handle any mismatch by adjusting the target stepper position
        // Calculate absolute position on the beam

        // 2. Perform any actions

        // Update the stepper motor mode and target position
        stepper_mode = MODE_DRIVE;

        // Drive the motor

        // 3. Calculate the next state
        if (stepper_pos == target_stepper_pos)
        {
            stepper_mode = MODE_IDLE;
            state = STATE_IDLE;

            if (direction == DIR_FORWARD)
            {
                direction = DIR_REVERSE;
                speed = SPEED_HIGH;
                // To change speed, set the start offset to set the count period
                stepper_period_offset = 0xFFFF - (250000 / (speed));
                target_stepper_pos = 0;
            }
            else
            {
                direction = DIR_FORWARD;
                speed = SPEED_LOW;
                // To change speed, set the start offset to set the count period
                stepper_period_offset = 0xFFFF - (250000 / (speed));
                target_stepper_pos = 400;
            }
        }
        break;

        case STATE_WAIT:
        // 1. Collect and process any inputs

        // 2. Perform any actions

        wait_count++; // Increment loop count

        // 3. Calculate the next state
        if (wait_count > wait_time)
        {
            state = STATE_DRIVE;
            wait_count = 0;
        }
        break;
    }
}

int16_t stepper_update(stepper_mode_t stepper_mode, uint16_t target_stepper_pos, uint16_t stepper_pos)
{
    static uint16_t current_speed = 0;
    static uint16_t acceleration = ACCELERATION;  // Adjust this value as needed
    static uint16_t max_speed = SPEED_LOW;  // Initial maximum speed
    static uint16_t deceleration_distance = ACCELERATION_DISTANCE;  // Adjust this value as needed
    static uint8_t decelerating = 0;

    // Check if it's been 60 seconds since the push button press
    if (sprint_state)
    {
        max_speed = SPEED_HIGH;  // Switch to maximum speed
    }

    switch (stepper_mode)
    {
        case MODE_IDLE:
        // Idle the motor when in MODE_IDLE
        idle_motor();
        break;

        case MODE_DRIVE:
		
	
		//********************_Wheel slip detection logic_**********************//
		
		// Calculate the difference between the target and current positions
		int16_t position_error = target_stepper_pos - stepper_pos;

		// Check if the motor is slipping
		if (abs(position_error) > slip_threshold)
		{
			// Increment the wheel slip counter
			wheel_slip_counter++;

			// If wheel slip is detected continuously for a certain threshold,
			// take corrective action (e.g., reduce motor power)
			if (wheel_slip_counter >= 5)
			{
				// Mitigate wheel slip by reducing motor power or taking appropriate action
				// For example, you can reduce the speed or take other corrective measures

				// Example: reduce motor speed by adjusting current_speed
				current_speed /= 2;

				// Reset the wheel slip counter
				wheel_slip_counter = 0;
			}
		}
		else
		{
			// Reset the wheel slip counter when no slip is detected
			wheel_slip_counter = 0;
		}
		
		
		//********************_Acceleration_logic_**********************//
		
        // Calculate the distance to the target position
        uint16_t distance_to_target = (target_stepper_pos > stepper_pos) ? (target_stepper_pos - stepper_pos) : (stepper_pos - target_stepper_pos);

        // Update speed based on acceleration and deceleration
        if (!decelerating && distance_to_target <= deceleration_distance)
        {
            decelerating = 1;
        }

        if (decelerating)
        {
            // Decelerate
            if (current_speed > acceleration)
            {
                current_speed -= acceleration;
            }
            else
            {
                current_speed = 0;
            }
        }
        else
        {
            // Accelerate
            if (current_speed < max_speed)
            {
                current_speed += acceleration;
            }
        }

        // Determine direction
        uint8_t dir = (target_stepper_pos > stepper_pos) ? 1 : 0;
		
		
		//********************_Motor drive logic_**********************//
		
        if (current_speed > 0)
        {
            // Move the motor
            step_motor(dir);
            if (dir)
            {
                stepper_pos++;
            }
            else
            {
                stepper_pos--;
            }
        }
        break;
    }

    return stepper_pos;
}

// Interrupts

// Timer to control the timing of stepper update
ISR(TIMER3_OVF_vect)
{
    // Set TCNT3L and TCNT3H to some value to set a precise period
    TCNT3 = stepper_period_offset;

    stepper_pos = stepper_update(stepper_mode, target_stepper_pos, stepper_pos);
}

// Timer to control the timing of periodic updates
// Alternatively, this could run at some multiple of stepper updates (timer 3 overflows)
ISR(TIMER4_OVF_vect)
{
    // Set TCNT4L and TCNT4H to some value to set a precise period
    TCNT4 = 0x9E57;
    STATE_UPDATE = true;
    current_time++;
}

// ADC Conversion complete
ISR(ADC_vect)
{
    // ADC conversion is triggered by Timer 1 by default, which is used to generate VREF by the stepper driver at ~500 Hz.
    // Alternatively, the ADC could be manually triggered in the main loop.
    // We can only read one ADC value at a time, so our sampling rate will be halved.

    // For now, the values are simply read and stored for interpretation/use by the state machine logic
    // This could be modified to add each value to a buffer and compute the mean or a filtered value
    adc_values[ADMUX & (1 << MUX0)] = ADCL | (ADCH << 8);

    // Change the channel to read the other pin on the next trigger
    ADMUX ^= (1 << MUX0);
}

// General pcint for user input controls and limit switches
ISR(PCINT2_vect)
{
    // Read the pin values to determine which pin changed
    // For some pins, we might only care about a rising edge

    if ((~(PIND & (1 << PIND2)))&& debounced_state_LS1) // LS1 pressed
    {
        LS1_state = true;
    }

    if ((~(PIND & (1 << PIND4)))&& debounced_state_LS2) // LS2 pressed
    {
        LS2_state = true;
    }

    if (~(PIND & (1 << PIND7)) && debounced_state_PB) // PB pressed
    {
        PB_state = true;
		LS1_state = false;
		LS2_state = false;
        debounced_state_PB = false;
    }
    else if(debounced_state_PB)
    {
        PB_state = false;
        debounced_state_PB = false;
    }
}
